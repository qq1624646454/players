Magic Sound Font v2.0

Contributed by Dennis Deutschmann