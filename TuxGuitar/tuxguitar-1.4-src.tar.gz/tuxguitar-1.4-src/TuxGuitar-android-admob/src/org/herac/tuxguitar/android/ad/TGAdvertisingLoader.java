package org.herac.tuxguitar.android.ad;

import org.herac.tuxguitar.android.fragment.TGFragmentEvent;
import org.herac.tuxguitar.event.TGEvent;
import org.herac.tuxguitar.event.TGEventException;
import org.herac.tuxguitar.event.TGEventListener;
import org.herac.tuxguitar.event.TGEventManager;
import org.herac.tuxguitar.util.TGContext;
import org.herac.tuxguitar.util.singleton.TGSingletonFactory;
import org.herac.tuxguitar.util.singleton.TGSingletonUtil;

public class TGAdvertisingLoader implements TGEventListener {
	
	private TGContext context;
	
	public TGAdvertisingLoader(TGContext context) {
		this.context = context;
	}
	
	public boolean tryInstall() {
		return TGAdvertisingManager.getInstance(this.context).install();
	}
	
	public void install() {
		if(!this.tryInstall() ) {
			this.registerInstallListeners();
		}
	}
	
	public void uninstall() {
		this.unregisterInstallListeners();
		
		TGAdvertisingManager.getInstance(this.context).uninstall();
	}
	
	public void registerInstallListeners() {
		TGEventManager.getInstance(this.context).addListener(TGFragmentEvent.EVENT_TYPE, this);
	}
	
	public void unregisterInstallListeners() {
		TGEventManager.getInstance(this.context).removeListener(TGFragmentEvent.EVENT_TYPE, this);
	}
	
	public void processEvent(TGEvent event) throws TGEventException {
		if( event.getEventType().equals(TGFragmentEvent.EVENT_TYPE) ) {
			if( TGFragmentEvent.ACTION_VIEW_CREATED.equals(event.getAttribute(TGFragmentEvent.ATTRIBUTE_ACTION)) ) {
				if( this.tryInstall() ) {
					this.unregisterInstallListeners();
				}
			}
		}
	}
	
	public static TGAdvertisingLoader getInstance(TGContext context) {
		return TGSingletonUtil.getInstance(context, TGAdvertisingLoader.class.getName(), new TGSingletonFactory<TGAdvertisingLoader>() {
			public TGAdvertisingLoader createInstance(TGContext context) {
				return new TGAdvertisingLoader(context);
			}
		});
	}
}
