package org.herac.tuxguitar.android.ad;

import org.herac.tuxguitar.android.R;
import org.herac.tuxguitar.android.fragment.impl.TGMainFragmentController;
import org.herac.tuxguitar.util.TGContext;
import org.herac.tuxguitar.util.plugin.TGPluginException;
import org.herac.tuxguitar.util.singleton.TGSingletonFactory;
import org.herac.tuxguitar.util.singleton.TGSingletonUtil;

import android.annotation.SuppressLint;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class TGAdvertisingManager {
	
//	private static final String AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";
	private static final String AD_UNIT_ID = "ca-app-pub-9066513795907661/9662942432";
	
	private TGContext context;
	
	public TGAdvertisingManager(TGContext context) {
		this.context = context;
	}
	
	public boolean install() {
		View container = this.findContainerView();
		if( container != null ) {
			((FrameLayout) container).addView(this.createAdView(container));
			
			return true;
		}
		return false;
	}
	
	public boolean uninstall() throws TGPluginException {
		View container = this.findContainerView();
		if( container != null ) {
			((FrameLayout) container).removeAllViews();
			
			return true;
		}
		return false;
	}
	
	public View findContainerView() {
		return TGMainFragmentController.getInstance(this.context).getFragment().getTopView();
	}
	
	@SuppressLint("InflateParams")
	public View createAdView(View container) {
		RelativeLayout relativeLayout = new RelativeLayout(container.getContext());
		relativeLayout.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
		relativeLayout.setBackgroundColor(R.color.darkColor);
		
		RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
		layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
		layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
		
		AdView adView = new AdView(container.getContext());
		adView.setBackgroundColor(R.color.darkColor);
		adView.setLayoutParams(layoutParams);
		adView.setAdSize(AdSize.BANNER);
		adView.setAdUnitId(AD_UNIT_ID);
        adView.loadAd(new AdRequest.Builder().build());
        
		relativeLayout.addView(adView);
		
		return relativeLayout;
	}
	
	public static TGAdvertisingManager getInstance(TGContext context) {
		return TGSingletonUtil.getInstance(context, TGAdvertisingManager.class.getName(), new TGSingletonFactory<TGAdvertisingManager>() {
			public TGAdvertisingManager createInstance(TGContext context) {
				return new TGAdvertisingManager(context);
			}
		});
	}
}
