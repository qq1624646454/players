package org.herac.tuxguitar.android.ad;

import org.herac.tuxguitar.util.TGContext;
import org.herac.tuxguitar.util.TGSynchronizer;
import org.herac.tuxguitar.util.plugin.TGPlugin;
import org.herac.tuxguitar.util.plugin.TGPluginException;

public class TGAdvertisingPlugin implements TGPlugin {
	
	private static final String MODULE_ID = "tuxguitar-android-ad";
	
	public String getModuleId() {
		return MODULE_ID;
	}

	public void connect(final TGContext context) throws TGPluginException {
		TGSynchronizer.getInstance(context).executeLater(new Runnable() {
			public void run() {
				TGAdvertisingLoader.getInstance(context).install();
			}
		});		
	}

	public void disconnect(final TGContext context) throws TGPluginException {
		TGSynchronizer.getInstance(context).executeLater(new Runnable() {
			public void run() {
				TGAdvertisingLoader.getInstance(context).uninstall();
			}
		});
	}
}
