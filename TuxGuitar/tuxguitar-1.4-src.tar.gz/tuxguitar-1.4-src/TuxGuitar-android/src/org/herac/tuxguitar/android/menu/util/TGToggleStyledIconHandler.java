package org.herac.tuxguitar.android.menu.util;

public interface TGToggleStyledIconHandler {
	
	Integer getMenuItemId();
	
	Integer resolveStyle();
}
