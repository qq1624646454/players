package org.herac.tuxguitar.android.view.dialog.chooser;

public interface TGChooserDialogHandler<T> {

	void onChoose(T value);
}
