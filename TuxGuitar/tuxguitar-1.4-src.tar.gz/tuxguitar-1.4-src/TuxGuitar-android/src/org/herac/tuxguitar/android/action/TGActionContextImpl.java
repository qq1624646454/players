package org.herac.tuxguitar.android.action;

import org.herac.tuxguitar.action.TGActionContext;

public class TGActionContextImpl extends TGActionContext{
	
	public TGActionContextImpl(){
		super();
	}
}
