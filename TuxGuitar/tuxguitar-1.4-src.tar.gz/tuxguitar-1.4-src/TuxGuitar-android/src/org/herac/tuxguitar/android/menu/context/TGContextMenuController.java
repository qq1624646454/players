package org.herac.tuxguitar.android.menu.context;

import android.view.ContextMenu;
import android.view.MenuInflater;

public interface TGContextMenuController {
	
	void inflate(ContextMenu menu, MenuInflater inflater);
}
