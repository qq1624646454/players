package org.herac.tuxguitar.android.view.dialog.bend;

public interface TGBendEditorListener {
	
	void onChange();
}
