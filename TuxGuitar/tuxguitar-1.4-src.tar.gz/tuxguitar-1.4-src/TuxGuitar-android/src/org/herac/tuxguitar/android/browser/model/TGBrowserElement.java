package org.herac.tuxguitar.android.browser.model;

public interface TGBrowserElement {
	
	String getName();
	
	boolean isFolder();
	
	boolean isWritable();
}
