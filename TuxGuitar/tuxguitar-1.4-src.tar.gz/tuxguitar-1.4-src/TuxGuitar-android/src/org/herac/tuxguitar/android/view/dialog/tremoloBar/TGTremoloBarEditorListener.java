package org.herac.tuxguitar.android.view.dialog.tremoloBar;

public interface TGTremoloBarEditorListener {
	
	void onChange();
}
