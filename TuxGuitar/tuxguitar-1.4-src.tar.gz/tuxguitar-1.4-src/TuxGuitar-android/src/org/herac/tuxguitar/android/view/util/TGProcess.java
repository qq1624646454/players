package org.herac.tuxguitar.android.view.util;

public interface TGProcess {
	
	void process();
}
