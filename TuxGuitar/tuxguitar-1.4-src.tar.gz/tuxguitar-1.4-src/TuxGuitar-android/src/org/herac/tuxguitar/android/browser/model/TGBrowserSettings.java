package org.herac.tuxguitar.android.browser.model;

public class TGBrowserSettings {
	
	private String title;
	private String data;
	
	public TGBrowserSettings() {
		super();
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
}