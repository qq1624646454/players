package org.herac.tuxguitar.android.application;

import android.app.Application;

public class TGApplication extends Application {
	
	public TGApplication() {
		super();
	}
}
