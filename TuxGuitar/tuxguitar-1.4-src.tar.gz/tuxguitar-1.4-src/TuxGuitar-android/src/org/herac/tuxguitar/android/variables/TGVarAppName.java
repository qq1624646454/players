package org.herac.tuxguitar.android.variables;

public class TGVarAppName {
	
	public static final String NAME = "appname";
	public static final String APPLICATION_NAME = "TuxGuitar";
	
	public String toString() {
		return APPLICATION_NAME;
	}
}
