package org.herac.tuxguitar.android.view.dialog;

import android.app.Activity;

public interface TGDialogController {
	
	void showDialog(Activity activity, TGDialogContext dialogContext);
}
