package org.herac.tuxguitar.android.view.dialog.browser.filesystem;

import java.io.File;

public interface TGBrowserSettingsFolderAdapterListener {

	void onPathChanged(File path);
}
