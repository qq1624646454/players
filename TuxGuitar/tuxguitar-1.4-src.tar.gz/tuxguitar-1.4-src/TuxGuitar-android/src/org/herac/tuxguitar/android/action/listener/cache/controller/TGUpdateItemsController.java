package org.herac.tuxguitar.android.action.listener.cache.controller;

public class TGUpdateItemsController extends TGUpdateCacheController {
	
	public TGUpdateItemsController() {
		super(true);
	}
}
