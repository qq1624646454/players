package org.herac.tuxguitar.android.action.listener.cache;

import org.herac.tuxguitar.action.TGActionContext;
import org.herac.tuxguitar.util.TGContext;

public interface TGUpdateController {
	
	void update(TGContext context, TGActionContext actionContext);
}
