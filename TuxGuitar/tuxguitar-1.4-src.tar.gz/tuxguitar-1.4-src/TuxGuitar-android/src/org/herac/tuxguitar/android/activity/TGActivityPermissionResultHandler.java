package org.herac.tuxguitar.android.activity;


public interface TGActivityPermissionResultHandler {
	
	void onRequestPermissionsResult(String[] permissions, int[] grantResults);
}
