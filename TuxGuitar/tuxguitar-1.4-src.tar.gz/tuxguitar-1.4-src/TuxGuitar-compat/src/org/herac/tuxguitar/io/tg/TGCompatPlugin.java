package org.herac.tuxguitar.io.tg;

public class TGCompatPlugin {
	
	public static final String MODULE_ID = "tuxguitar-compat";
}
