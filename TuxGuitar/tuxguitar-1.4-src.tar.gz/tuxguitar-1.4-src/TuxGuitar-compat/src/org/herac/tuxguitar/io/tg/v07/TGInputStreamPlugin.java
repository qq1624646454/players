package org.herac.tuxguitar.io.tg.v07;

import org.herac.tuxguitar.io.tg.TGInputStreamPluginImpl;

public class TGInputStreamPlugin extends TGInputStreamPluginImpl{

	public TGInputStreamPlugin() {
		super(new TGInputStream());
	}
}
